<?php
/**
 * @version        3.4.1
 * @package        Joomla
 * @subpackage     Membership Pro
 * @author         Tuan Pham Ngoc
 * @copyright      Copyright (C) 2012 - 2023 Ossolution Team
 * @license        GNU/GPL, see LICENSE.php
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;

class plgSystemOSMembershipAkeeba extends JPlugin
{
	public function onAfterRoute()
	{
		if (!file_exists(JPATH_ROOT . '/components/com_osmembership/osmembership.php'))
		{
			return true;
		}

		$app = Factory::getApplication();

		if ($app->isClient('administrator'))
		{
			return true;
		}

		$option        = $app->input->getCmd('option');
		$view          = $app->input->getCmd('view');
		$paymentMethod = $app->input->getCmd('paymentmethod');

		if ($option == 'com_akeebasubs' && $view == 'callback' && $paymentMethod == 'paypal')
		{
			// Let Membership Pro handle it
			$app->input->set('option', 'com_osmembership');
			$app->input->set('task', 'recurring_payment_confirm');
			$app->input->set('payment_method', 'os_paypal');
			$app->input->get->set('akeebasubs', 1);
		}
	}
}