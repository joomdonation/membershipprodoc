<?php
/**
 * @version        3.4.1
 * @package        Joomla
 * @subpackage     Membership Pro
 * @author         Tuan Pham Ngoc
 * @copyright      Copyright (C) 2012 - 2023 Ossolution Team
 * @license        GNU/GPL, see LICENSE.php
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;

class plgSystemAec2OsMembership extends JPlugin
{
	public function onAfterRoute()
	{
		if (!file_exists(JPATH_ROOT . '/components/com_osmembership/osmembership.php'))
		{
			return true;
		}

		$app = Factory::getApplication();

		if ($app->isClient('administrator'))
		{
			return true;
		}

		$option = $app->input->getCmd('option');
		$task   = $app->input->getCmd('task');

		if ($option == 'com_acctexp' && $task == 'paypal_subscriptionnotification')
		{
			// Let Membership Pro handle it
			$app->input->set('option', 'com_osmembership');
			$app->input->set('task', 'recurring_payment_confirm');
			$app->input->set('payment_method', 'os_paypal');
			$app->input->get->set('aec', 1);
		}
	}
}