<?php
/**
 * @package        Joomla
 * @subpackage     Membership Pro
 * @author         Tuan Pham Ngoc
 * @copyright      Copyright (C) 2012 - 2019 Ossolution Team
 * @license        GNU/GPL, see LICENSE.php
 */

use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\PluginHelper;

defined('_JEXEC') or die;

if (!(defined('_VALID_CB') || defined('_JEXEC') || defined('_VALID_MOS')))
{
	die('Direct Access to this location is not allowed.');
}

global $_PLUGINS;
$_PLUGINS->loadPluginGroup('user');
$_PLUGINS->registerFunction('onAfterUserProfileSaved', 'onAfterUserProfileSaved', 'CBMembershipPro');

class CBMembershipPro extends cbPluginHandler
{
	public function onAfterUserProfileSaved($cbUser, $ui)
	{
		if (!PluginHelper::isEnabled('osmembership', 'cb'))
		{
			return;
		}

		$db    = Factory::getContainer()->get('db');
		$query = $db->getQuery(true);
		$query->select('id')
			->from('#__osmembership_subscribers')
			->where('user_id = ' . $cbUser->id);
		$db->setQuery($query);
		$subscriptionIds = $db->loadColumn();

		if (!count($subscriptionIds))
		{
			return;
		}

		$query->clear()
			->select('id, name, field_mapping, is_core')
			->from('#__osmembership_fields')
			->where('CHAR_LENGTH(field_mapping) > 0');
		$db->setQuery($query);
		$rowFields = $db->loadObjectList();

		// No fields are mapped, don't process further
		if (!count($rowFields))
		{
			return;
		}

		// Require library + register autoloader
		require_once JPATH_ADMINISTRATOR . '/components/com_osmembership/loader.php';

		foreach ($subscriptionIds as $subscriptionId)
		{
			/*@var OSMembershipTableSubscriber $rowSubscription*/
			$rowSubscription = new OSMembershipTableSubscriber($db);
			$rowSubscription->load($subscriptionId);
			$coreFieldsChange = false;

			$query->clear()
				->select('*')
				->from('#__osmembership_field_value')
				->where('subscriber_id = ' . $subscriptionId);
			$db->setQuery($query);
			$fieldValues = $db->loadObjectList('field_id');

			foreach ($rowFields as $rowField)
			{
				if (!property_exists($cbUser, $rowField->field_mapping))
				{
					continue;
				}

				$userFieldValue = $cbUser->{$rowField->field_mapping};

				if ($rowField->is_core)
				{
					$rowSubscription->{$rowField->name} = $userFieldValue;
					$coreFieldsChange                   = true;
				}
				else
				{
					if (array_key_exists($rowField->id, $fieldValues))
					{
						// Field is already exist, update
						$query->clear()
							->update('#__osmembership_field_value')
							->set('field_value = ' . $db->quote($userFieldValue))
							->where('id = ' . $fieldValues[$rowField->id]->id);
						$db->setQuery($query)
							->execute();
					}
					else
					{
						// Field is not existed, insert new record
						$query->clear()
							->insert('#__osmembership_field_value')
							->columns($db->quoteName(['subscriber_id', 'field_id', 'field_value']))
							->values(implode(',', $db->quote([$subscriptionId, $rowField->id, $userFieldValue])));
						$db->setQuery($query)
							->execute();
					}
				}
			}

			if ($coreFieldsChange)
			{
				$rowSubscription->store();
			}
		}
	}
}